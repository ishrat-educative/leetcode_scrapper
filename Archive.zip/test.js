var fs = require("fs");

async function tests() {
  try {
    var result = await fs.readFile("1.xlsx");
    console.log(result);
  } catch (eerr) {
    console.log(eerr);
  }
}

tests();
